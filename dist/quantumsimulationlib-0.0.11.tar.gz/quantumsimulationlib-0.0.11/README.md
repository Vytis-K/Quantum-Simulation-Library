# Quantum Simulation Package

This is a quantum simulation package. Currently a work in progress.

Provides quantum walk for Fourier, Grover, and Hadamar coins, as well as visualizations and a basic GUI.

Quantum machine learning, network, entangled and multidimensional quantum computing applications using QSKit.

Has basic outline for machine learning methods and network, as well as multidimensional and higher dimensional walks, as well as entangled walks.